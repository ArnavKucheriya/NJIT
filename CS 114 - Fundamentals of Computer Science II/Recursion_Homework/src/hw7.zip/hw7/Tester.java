package hw7;


import binaryTrees.*;
import dictionaries.*;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	

}
