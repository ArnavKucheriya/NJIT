package hw7;

import binaryTrees.*;

public class Q4_Trees {
    static BinNode<Integer> T1;
    static BinNode<Integer> T2;

    /**
     * Constructs the trees T1 and T2 and prints them out in preorder, inorder, and postorder.
     */
    public static void constructTrees() {
        // Construct T1
        T1 = new BinNode<>(10);
        T1.setLeft(new BinNode<>(5));
        T1.setright(new BinNode<>(12));
        T1.left().setLeft(new BinNode<>(3));
        T1.right().setLeft(new BinNode<>(40));
        T1.right().setright(new BinNode<>(1));

        // Construct T2
        T2 = new BinNode<>(6);
        T2.setLeft(new BinNode<>(30));
        T2.setright(new BinNode<>(12));
        T2.left().setLeft(new BinNode<>(9));
        T2.right().setLeft(new BinNode<>(40));
        T2.right().setright(new BinNode<>(1));

        // Print trees in different orders
        System.out.println("T1 Preorder:");
        TreePrinter.preOrder(T1);
        System.out.println("\nT1 Inorder:");
        TreePrinter.inOrder(T1);
        System.out.println("\nT1 Postorder:");
        TreePrinter.postOrder(T1);

        System.out.println("\nT2 Preorder:");
        TreePrinter.preOrder(T2);
        System.out.println("\nT2 Inorder:");
        TreePrinter.inOrder(T2);
        System.out.println("\nT2 Postorder:");
        TreePrinter.postOrder(T2);
    }

    /**
     * Counts the number of leaf nodes in the tree with root `rt`.
     */
    public static int countLeafs(BinNode<Integer> rt) {
        if (rt == null) {
            return 0; // Base case: empty tree
        }
        if (rt.left() == null && rt.right() == null) {
            return 1; // Base case: leaf node
        }
        return countLeafs(rt.left()) + countLeafs(rt.right()); // Recursive case
    }

    /**
     * Returns the evil twin of the tree by swapping left and right subtrees recursively.
     */
    static BinNode<Integer> evilTwin(BinNode<Integer> root) {
        if (root == null) {
            return null;
        }

        // Create evil twin recursively
        BinNode<Integer> left = evilTwin(root.left());
        BinNode<Integer> right = evilTwin(root.right());

        // Swap the left and right subtrees
        root.setLeft(right);
        root.setright(left);

        return root;
    }

    /**
     * Main method for testing the implementations.
     */
    public static void main(String[] args) {
        // Construct and print trees
        constructTrees();

        // Count leaf nodes in T1 and T2
        System.out.println("\nNumber of leaf nodes in T1: " + countLeafs(T1));
        System.out.println("Number of leaf nodes in T2: " + countLeafs(T2));

        // Create and print evil twin trees
        BinNode<Integer> evilTwinT1 = evilTwin(T1);
        System.out.println("\nEvil Twin of T1 Preorder:");
        TreePrinter.preOrder(evilTwinT1);

        BinNode<Integer> evilTwinT2 = evilTwin(T2);
        System.out.println("\nEvil Twin of T2 Preorder:");
        TreePrinter.preOrder(evilTwinT2);
    }
}
