package linearStructures;

import linearStructures.queues.QueueADT;
import linearStructures.stacks.AStack;
import linearStructures.stacks.StackADT;

public class Hw6 {
	public static boolean isBalanced(String str) {
		//TODO
		return false; //STUB
	}
	
	public static String inBinary(String Decimal) {
		//TO DO
		return ""; //STUB
	}
	
	public static QueueADT<Integer> differenceQueue(QueueADT<Integer> q) {
		//TO DO
		return q ; //STUB
	}
	
	public static QueueADT<Integer> mergeQueues(QueueADT<Integer> q1, QueueADT<Integer> q2){
		//TO DO
		return q1; //STUB
		
	}
	
	
	/**
	 * Example:
	 * Returns True if w is a palindrome, false otherwise
	 */
	public static boolean isPalindrome(String w) {
		
		char[] cw =  w.toCharArray();
		// second half of the word
		int secondHalf =  (cw.length / 2);
		
		StackADT<Character> s = new AStack<Character>();
		
		// Stack first half of word
		for (int i = 0; i < (cw.length / 2) ; ++i) {
			s.push(cw[i]);
		}
		
		// If length is odd, ignore the middle character, as it will not have a match
		if (w.length() % 2 == 1){
			secondHalf += 1;
		}
		
		// Compare second half to see if it is the mirror image of the first half
		for (int i = secondHalf; i < cw.length; ++i) {
			if (cw[i] != s.pop()) {
				return false;
			}
		}
		// all matched
		return true;
		
	}
}
